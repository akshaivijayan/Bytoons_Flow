const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('server/db.sqlite');

db.all("SELECT DISTINCT assetCategory FROM assets", [], (err, rows) => {
    if (err) {
        console.error(err);
    } else {
        console.log('Categories:', rows.map(r => r.assetCategory));
    }
    db.close();
});
